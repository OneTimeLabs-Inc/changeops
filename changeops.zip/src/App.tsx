import {
  Bell,
  CalendarDays,
  CheckSquare2,
  ClipboardList,
  FileClock,
  Gauge,
  History,
  Menu,
  Plus,
  Settings,
  ShieldCheck,
  X,
} from "lucide-react";
import { useCallback, useMemo, useState } from "react";

import "./App.css";

import AuthGate from "./components/AuthGate";
import ChangeDetail from "./components/ChangeDetail";
import LicenseGate from "./components/LicenseGate";
import NewChangeDialog from "./components/NewChangeDialog";
import { productConfig } from "./config/productConfig";
import ApprovalsPage from "./pages/ApprovalsPage";
import AuditPage from "./pages/AuditPage";
import CalendarPage from "./pages/CalendarPage";
import ChangesPage from "./pages/ChangesPage";
import Dashboard from "./pages/Dashboard";
import SettingsPage from "./pages/SettingsPage";
import {
  clearLicense,
  type StoredLicenseState,
} from "./services/licensing";
import {
  loadAudit,
  loadChanges,
  nextChangeNumber,
  saveAudit,
  saveChanges,
  statusForApproval,
} from "./services/storage";
import type { AuditEvent, ChangeRequest } from "./types/change";

type View = "dashboard" | "changes" | "calendar" | "approvals" | "audit" | "settings";

const navItems: Array<{ id: View; label: string; icon: React.ReactNode }> = [
  { id: "dashboard", label: "Overview", icon: <Gauge size={17} /> },
  { id: "changes", label: "Changes", icon: <ClipboardList size={17} /> },
  { id: "calendar", label: "Calendar", icon: <CalendarDays size={17} /> },
  { id: "approvals", label: "Approvals", icon: <CheckSquare2 size={17} /> },
  { id: "audit", label: "Audit", icon: <History size={17} /> },
  { id: "settings", label: "Settings", icon: <Settings size={17} /> },
];

/* ==========================================================
   APP 001
   ChangeOps application root
   ========================================================== */

export default function App() {
  const [licenseState, setLicenseState] = useState<StoredLicenseState | null>(null);

  const handleLicenseState = useCallback((state: StoredLicenseState | null) => {
    setLicenseState(state);
  }, []);

  return (
    <LicenseGate onLicenseState={handleLicenseState}>
      <AuthGate>
        <ChangeOpsApplication
          licenseState={licenseState}
          onLicenseState={handleLicenseState}
        />
      </AuthGate>
    </LicenseGate>
  );
}

/* ==========================================================
   APP 002
   Licensed ChangeOps workspace
   ========================================================== */

function ChangeOpsApplication({
  licenseState,
  onLicenseState,
}: {
  licenseState: StoredLicenseState | null;
  onLicenseState: (state: StoredLicenseState | null) => void;
}) {
  const [view, setView] = useState<View>("dashboard");
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [changes, setChanges] = useState<ChangeRequest[]>(() => loadChanges());
  const [audit, setAudit] = useState<AuditEvent[]>(() => loadAudit());
  const [newDialogOpen, setNewDialogOpen] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const selectedChange = useMemo(
    () => changes.find((change) => change.id === selectedId) ?? null,
    [changes, selectedId],
  );

  const pendingApprovals = changes.filter((change) => change.approvalState === "Pending").length;

  function persistChanges(next: ChangeRequest[]) {
    setChanges(next);
    saveChanges(next);
  }

  function addAudit(event: Omit<AuditEvent, "id" | "createdAt">) {
    const next: AuditEvent[] = [
      {
        ...event,
        id: crypto.randomUUID(),
        createdAt: new Date().toISOString(),
      },
      ...audit,
    ];
    setAudit(next);
    saveAudit(next);
  }

  function createChange(change: ChangeRequest) {
    const next = [change, ...changes];
    persistChanges(next);
    addAudit({
      changeId: change.id,
      changeNumber: change.number,
      action: "Change created",
      detail: `${change.title} was created and submitted for approval.`,
      actor: change.requestedBy || "Change requester",
    });
    setNewDialogOpen(false);
    setSelectedId(change.id);
  }

  function setApproval(change: ChangeRequest, approved: boolean) {
    const now = new Date().toISOString();
    const next = changes.map((item) =>
      item.id === change.id
        ? {
            ...item,
            approvalState: approved ? ("Approved" as const) : ("Rejected" as const),
            status: statusForApproval(approved),
            updatedAt: now,
          }
        : item,
    );
    persistChanges(next);
    addAudit({
      changeId: change.id,
      changeNumber: change.number,
      action: approved ? "Change approved" : "Change rejected",
      detail: approved
        ? "Approval was recorded and the change was moved to Scheduled."
        : "The change was rejected and returned to Draft.",
      actor: "Change approver",
    });
  }

  function completeChange(change: ChangeRequest) {
    const next = changes.map((item) =>
      item.id === change.id
        ? { ...item, status: "Completed" as const, updatedAt: new Date().toISOString() }
        : item,
    );
    persistChanges(next);
    addAudit({
      changeId: change.id,
      changeNumber: change.number,
      action: "Change completed",
      detail: "Execution was marked complete. Validation and closure recorded in ChangeOps.",
      actor: change.owner,
    });
  }

  function deactivateLicense() {
    clearLicense();
    onLicenseState(null);
    window.location.reload();
  }

  const page = (() => {
    switch (view) {
      case "changes":
        return <ChangesPage changes={changes} onCreate={() => setNewDialogOpen(true)} onOpen={(change) => setSelectedId(change.id)} />;
      case "calendar":
        return <CalendarPage changes={changes} onOpen={(change) => setSelectedId(change.id)} />;
      case "approvals":
        return <ApprovalsPage changes={changes} onOpen={(change) => setSelectedId(change.id)} onApprove={(change) => setApproval(change, true)} onReject={(change) => setApproval(change, false)} />;
      case "audit":
        return <AuditPage events={audit} />;
      case "settings":
        return <SettingsPage licenseState={licenseState} onDeactivate={deactivateLicense} />;
      default:
        return <Dashboard changes={changes} onCreate={() => setNewDialogOpen(true)} onOpen={(change) => setSelectedId(change.id)} />;
    }
  })();

  return (
    <div className="app-shell">
      {/* =====================================================
          NAVIGATION 003
          ===================================================== */}
      <aside className={`sidebar ${mobileNavOpen ? "sidebar-open" : ""}`}>
        <div className="brand-block">
          <div className="brand-mark">CH</div>
          <div><strong>ChangeOps</strong><span>OneTime Labs</span></div>
          <button className="mobile-close" type="button" onClick={() => setMobileNavOpen(false)}><X size={18} /></button>
        </div>

        <nav className="side-nav" aria-label="ChangeOps navigation">
          <span className="nav-label">WORKSPACE</span>
          {navItems.map((item) => (
            <button
              key={item.id}
              className={view === item.id ? "active" : ""}
              onClick={() => {
                setView(item.id);
                setMobileNavOpen(false);
              }}
            >
              {item.icon}
              <span>{item.label}</span>
              {item.id === "approvals" && pendingApprovals > 0 && <em>{pendingApprovals}</em>}
            </button>
          ))}
        </nav>

        <div className="sidebar-license">
          <ShieldCheck size={16} />
          <div><strong>{licenseState ? "Licensed" : "Prototype mode"}</strong><span>{productConfig.slug} · v{productConfig.version}</span></div>
        </div>
      </aside>

      {/* =====================================================
          MAIN SHELL 004
          ===================================================== */}
      <div className="main-shell">
        <header className="topbar">
          <div className="topbar-left">
            <button className="mobile-menu" type="button" onClick={() => setMobileNavOpen(true)}><Menu size={18} /></button>
            <div className="breadcrumb"><FileClock size={15} /><span>Change Management</span><strong>/</strong><span>{navItems.find((item) => item.id === view)?.label}</span></div>
          </div>
          <div className="topbar-actions">
            <button className="top-icon" type="button" aria-label="Notifications"><Bell size={16} />{pendingApprovals > 0 && <span />}</button>
            <button className="new-change-button" type="button" onClick={() => setNewDialogOpen(true)}><Plus size={15} /> New Change</button>
            <div className="user-chip"><div>OTL</div><span><strong>Change Manager</strong><small>Operations</small></span></div>
          </div>
        </header>

        <main className="content-area">{page}</main>

        <footer className="statusbar">
          <div><span className="status-dot" /> Connected</div>
          <div><span>{productConfig.name}</span><span>{licenseState ? "License active" : "Local prototype"}</span><span>v{productConfig.version}</span></div>
        </footer>
      </div>

      {newDialogOpen && <NewChangeDialog number={nextChangeNumber(changes)} onClose={() => setNewDialogOpen(false)} onCreate={createChange} />}
      {selectedChange && <ChangeDetail change={selectedChange} onClose={() => setSelectedId(null)} onApprove={() => setApproval(selectedChange, true)} onReject={() => setApproval(selectedChange, false)} onComplete={() => completeChange(selectedChange)} />}
    </div>
  );
}
