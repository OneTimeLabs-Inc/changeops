export type ChangeRisk = "Low" | "Medium" | "High" | "Critical";
export type ChangeStatus =
  | "Draft"
  | "Pending Approval"
  | "Scheduled"
  | "In Progress"
  | "Completed"
  | "Failed"
  | "Cancelled";
export type ChangeType = "Standard" | "Normal" | "Emergency";
export type ApprovalState = "Not Required" | "Pending" | "Approved" | "Rejected";

export interface ChangeRequest {
  id: string;
  number: string;
  title: string;
  description: string;
  type: ChangeType;
  risk: ChangeRisk;
  status: ChangeStatus;
  approvalState: ApprovalState;
  owner: string;
  requestedBy: string;
  affectedService: string;
  scheduledStart: string;
  scheduledEnd: string;
  impact: string;
  implementationPlan: string;
  validationPlan: string;
  backoutPlan: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditEvent {
  id: string;
  changeId: string | null;
  changeNumber: string | null;
  action: string;
  detail: string;
  actor: string;
  createdAt: string;
}
