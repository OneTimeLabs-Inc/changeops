import { createClient } from "@supabase/supabase-js";
import { env } from "../config/env";

/**
 * Central OneTime Labs licensing client.
 *
 * This client intentionally points to the shared OTLES/Licensing Supabase
 * project, not the ChangeOps application database. ChangeOps must never
 * maintain its own licensing tables or treat its application database as the
 * source of truth for entitlements.
 */
export const licensingSupabase = createClient(
  env.licensingSupabaseUrl,
  env.licensingSupabasePublishableKey,
  {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
  },
);
