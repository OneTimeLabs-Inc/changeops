function requiredEnv(name: string, value: string | undefined): string {
  const normalized = value?.trim();
  if (!normalized) {
    throw new Error(`${name} is required.`);
  }
  return normalized;
}

export const env = {
  // ChangeOps application project
  supabaseUrl: requiredEnv(
    "VITE_SUPABASE_URL",
    import.meta.env.VITE_SUPABASE_URL,
  ),
  supabasePublishableKey: requiredEnv(
    "VITE_SUPABASE_PUBLISHABLE_KEY",
    import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
  ),

  // Central OneTime Labs licensing project
  licensingSupabaseUrl: requiredEnv(
    "VITE_LICENSING_SUPABASE_URL",
    import.meta.env.VITE_LICENSING_SUPABASE_URL,
  ),
  licensingSupabasePublishableKey: requiredEnv(
    "VITE_LICENSING_SUPABASE_PUBLISHABLE_KEY",
    import.meta.env.VITE_LICENSING_SUPABASE_PUBLISHABLE_KEY,
  ),

  demoMode: import.meta.env.VITE_DEMO_MODE === "true",
  authRequired: import.meta.env.VITE_AUTH_REQUIRED === "true",
};
