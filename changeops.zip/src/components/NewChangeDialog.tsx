import { useState, type FormEvent } from "react";
import { X } from "lucide-react";
import type { ChangeRequest, ChangeRisk, ChangeType } from "../types/change";

interface Props {
  number: string;
  onClose: () => void;
  onCreate: (change: ChangeRequest) => void;
}

const fieldDefaults = {
  title: "",
  description: "",
  type: "Normal" as ChangeType,
  risk: "Medium" as ChangeRisk,
  owner: "",
  requestedBy: "",
  affectedService: "",
  scheduledStart: "",
  scheduledEnd: "",
  impact: "",
  implementationPlan: "",
  validationPlan: "",
  backoutPlan: "",
};

export default function NewChangeDialog({ number, onClose, onCreate }: Props) {
  const [form, setForm] = useState(fieldDefaults);

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const now = new Date().toISOString();
    onCreate({
      id: crypto.randomUUID(),
      number,
      ...form,
      status: "Pending Approval",
      approvalState: "Pending",
      createdAt: now,
      updatedAt: now,
    });
  }

  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section className="modal-card change-dialog" role="dialog" aria-modal="true" onMouseDown={(event) => event.stopPropagation()}>
        <header className="modal-header">
          <div><span>NEW CHANGE</span><h2>{number}</h2></div>
          <button type="button" className="icon-button" onClick={onClose}><X size={18} /></button>
        </header>
        <form onSubmit={submit} className="change-form">
          <div className="form-grid two-col">
            <label className="span-2">Title<input required value={form.title} onChange={(e) => update("title", e.target.value)} placeholder="Describe the planned change" /></label>
            <label>Type<select value={form.type} onChange={(e) => update("type", e.target.value as ChangeType)}><option>Standard</option><option>Normal</option><option>Emergency</option></select></label>
            <label>Risk<select value={form.risk} onChange={(e) => update("risk", e.target.value as ChangeRisk)}><option>Low</option><option>Medium</option><option>High</option><option>Critical</option></select></label>
            <label>Owner<input required value={form.owner} onChange={(e) => update("owner", e.target.value)} /></label>
            <label>Requested by<input required value={form.requestedBy} onChange={(e) => update("requestedBy", e.target.value)} /></label>
            <label className="span-2">Affected service<input required value={form.affectedService} onChange={(e) => update("affectedService", e.target.value)} /></label>
            <label>Scheduled start<input type="datetime-local" value={form.scheduledStart} onChange={(e) => update("scheduledStart", e.target.value)} /></label>
            <label>Scheduled end<input type="datetime-local" value={form.scheduledEnd} onChange={(e) => update("scheduledEnd", e.target.value)} /></label>
            <label className="span-2">Description<textarea rows={3} value={form.description} onChange={(e) => update("description", e.target.value)} /></label>
            <label className="span-2">Impact<textarea rows={2} value={form.impact} onChange={(e) => update("impact", e.target.value)} /></label>
            <label className="span-2">Implementation plan<textarea required rows={3} value={form.implementationPlan} onChange={(e) => update("implementationPlan", e.target.value)} /></label>
            <label className="span-2">Validation plan<textarea rows={2} value={form.validationPlan} onChange={(e) => update("validationPlan", e.target.value)} /></label>
            <label className="span-2">Backout plan<textarea rows={2} value={form.backoutPlan} onChange={(e) => update("backoutPlan", e.target.value)} /></label>
          </div>
          <footer className="modal-footer">
            <button type="button" className="secondary-button" onClick={onClose}>Cancel</button>
            <button type="submit" className="primary-button">Create & Submit</button>
          </footer>
        </form>
      </section>
    </div>
  );
}
